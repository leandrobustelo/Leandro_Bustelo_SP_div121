
package modelo;

import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;


public interface Inventariable<T> {
    
    void agregar(T elemento);
   
   T obtener(int indice);
   
   void eliminar(int indice);
    
   List<T> filtrar(Predicate<?super T>criterio);
   
   void ordenar();
   
   void ordenar(Comparator<T> comp);
   
   void guardarEnBinario(String path);
   
   void cargarDesdeBinario(String path);
   
   void guardarEnCSV(String path);
   
   void cargarDesdeCSV(String path,Function<String, T> lineaToObjetos);
}
