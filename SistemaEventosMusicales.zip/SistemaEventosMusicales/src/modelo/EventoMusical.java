
package modelo;

import java.time.LocalDate;


public class EventoMusical extends Evento implements Comparable<EventoMusical>{
    private String artista;
    private GeneroMusical genero;

    public EventoMusical(int id, String nombre, LocalDate fecha,String artista, GeneroMusical genero) {
        super(id, nombre, fecha);
        this.artista=artista;
        this.genero=genero;
    }

    @Override
    public int compareTo(EventoMusical o) {
        return this.fecha.compareTo(o.fecha);
    }

    public GeneroMusical getGenero() {
        return genero;
    }

    public String getArtista() {
        return artista;
    }
    
    public String toCSV() {
        return super.getId()+","+super.getNombre()+","+fecha+","+artista+","+genero;
    }
    
    public static EventoMusical fromCSV(String linea){
        String[]data=linea.split(",");
        return new EventoMusical(Integer.parseInt(data[0]),data[1],LocalDate.parse((data[2])),data[3],GeneroMusical.valueOf(data[4]));
    }
}
