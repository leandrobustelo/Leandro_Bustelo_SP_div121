
package Servicio;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import modelo.Evento;
import modelo.EventoMusical;
import modelo.Inventariable;


public class GestorEventos<T extends Evento> implements Inventariable<T>{
    
    List<T>items=new ArrayList();
    
    @Override
    public void agregar(T elemento) {
        if(elemento==null){
            throw new IllegalArgumentException("no se deben almacenar nulos");
        }
        items.add(elemento);
    }

    @Override
    public T obtener(int indice) {
        validarIndice(indice);
        return items.get(indice);
    }

    @Override
    public void eliminar(int indice) {
        validarIndice(indice);
        items.remove(indice);

    }
    
    private void validarIndice(int indice){
        if(indice<0||indice>=items.size()){
             throw new IndexOutOfBoundsException();
        }
    } 
        
    @Override
    public List<T> filtrar(Predicate<? super T> criterio) {
        
        List<T>retorno=new ArrayList();
        for(T t :items){
           if(criterio.test(t)){
               retorno.add(t);
           }
        }
        return retorno;
    }

    @Override
    public void ordenar() {
        items.sort(null);
    }

    @Override
    public void ordenar(Comparator<T> comp) {
        items.sort(comp);
    }
    
    public List<T> buscarPorRango(LocalDate l1,LocalDate l2){
        List<T>retorno=new ArrayList();
        
        for(T elemento:items){
            if(elemento instanceof EventoMusical e){
                LocalDate fecha = elemento.getFecha();
                if ((fecha.isEqual(l1) || fecha.isAfter(l1)) && (fecha.isEqual(l2) || fecha.isBefore(l2))) {
                    retorno.add(elemento);
                }
            }
        }
        return retorno;
    }
    
    @Override
    public void guardarEnBinario(String path) {
        
        try(FileOutputStream archivo2 = new FileOutputStream(path);
            ObjectOutputStream salida= new ObjectOutputStream(archivo2)){
            
            salida.writeObject(items);
        }catch(IOException ex){
            ex.printStackTrace();
        }
    }

    @Override
    public void cargarDesdeBinario(String path) {
        items.clear();
        try(ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))){
            
            items=(List<T>)entrada.readObject();
            
        }catch(IOException | ClassNotFoundException ex){
            ex.printStackTrace();
        }
    }

    @Override
    public void guardarEnCSV(String path) {
        File archivo = new File(path);
         
        verificarArchivo(archivo);
        
        try(BufferedWriter bw= new BufferedWriter(new FileWriter(archivo))){
            bw.write("ID,nombre,fecha,artista,genero"+"\n");
            
           for(T t:items){
               if(t instanceof EventoMusical e){
                bw.write(e.toCSV()+"\n");
               }
           }
        }catch(IOException ex){
            ex.printStackTrace();
        }
    }
    
    @Override   
    public void cargarDesdeCSV(String path,Function<String, T> lineaToObjeto) {
        File archivo=new File(path);
        items.clear();
        
        try(BufferedReader bf= new BufferedReader(new FileReader(archivo))){
            String linea;
            bf.readLine();
            
            while((linea=bf.readLine())!=null){
                if(linea.endsWith("\n")){
                    linea=linea.substring(linea.length()-1);
                }
               
                items.add(lineaToObjeto.apply(linea));
                 
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
        
    private static void verificarArchivo(File archivo){
        
        if(archivo.exists()){
            System.out.println("el archivo ya existe");
        }
        else{
            try {
                archivo.createNewFile();
                System.out.println("se ha creado el archivo");
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
        }
    } 
    
    public void limpiar(){
        items.clear();
    }
    
    public void mostrarTodos(){
        for(T t :items){
            System.out.println(t);
        }
    }
}
